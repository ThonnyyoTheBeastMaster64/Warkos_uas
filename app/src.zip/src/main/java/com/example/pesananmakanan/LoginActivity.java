package com.example.pesananmakanan;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private ProgressBar progressLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        progressLogin = findViewById(R.id.progressLogin);

        findViewById(R.id.tvLupaPassword).setOnClickListener(v -> mintaOtp());
        findViewById(R.id.btnRegister).setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });
        btnLogin.setOnClickListener(v -> validasiDanLogin());
    }

    private void mintaOtp() {
        String email = etEmail.getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Isi email dulu untuk minta OTP");
            return;
        }

        progressLogin.setVisibility(View.VISIBLE);
        StringRequest request = new StringRequest(Request.Method.POST, ApiConfig.OTP_REQUEST_URL,
                response -> {
                    progressLogin.setVisibility(View.GONE);
                    if (response.contains("success")) {
                        // Jika ada debug OTP di JSON (untuk testing)
                        Toast.makeText(this, "OTP terkirim!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(this, OTPActivity.class);
                        intent.putExtra("email", email);
                        startActivity(intent);
                    } else {
                        Toast.makeText(this, "Gagal mengirim OTP", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressLogin.setVisibility(View.GONE);
                    Toast.makeText(this, "Server tidak merespon", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                return params;
            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(request);
    }

    private void validasiDanLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // ----- VALIDASI INPUT -----
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email wajib diisi");
            etEmail.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Format email tidak valid");
            etEmail.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password wajib diisi");
            etPassword.requestFocus();
            return;
        }
        if (password.length() < 8) {
            // BUG FIX: was `< 4`, which allows very weak passwords
            // (e.g. "1234"). 8 chars is a more reasonable floor; the
            // real strength check (hashing, breach checks, etc.) still
            // belongs on the server, but the client shouldn't accept
            // trivially guessable passwords either.
            etPassword.setError("Password minimal 8 karakter");
            etPassword.requestFocus();
            return;
        }

        loginKeServer(email, password);
    }

    private void loginKeServer(String email, String password) {
        progressLogin.setVisibility(View.VISIBLE);
        btnLogin.setEnabled(false);

        JSONObject body = new JSONObject();
        try {
            body.put("email", email);
            body.put("password", password);
        } catch (Exception e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, ApiConfig.LOGIN_URL, body,
                response -> {
                    progressLogin.setVisibility(View.GONE);
                    btnLogin.setEnabled(true);
                    try {
                        String status = response.getString("status");
                        if ("success".equals(status)) {
                            String role = response.getString("role");
                            Toast.makeText(this, "Login sebagai " + role, Toast.LENGTH_SHORT).show();

                            Intent intent;
                            switch (role) {
                                case "admin":
                                    intent = new Intent(LoginActivity.this, AdminMainActivity.class);
                                    break;
                                default:
                                    intent = new Intent(LoginActivity.this, KasirActivity.class);
                                    break;
                            }
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, response.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "Terjadi kesalahan data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressLogin.setVisibility(View.GONE);
                    btnLogin.setEnabled(true);
                    String message = "Gagal terhubung ke server";
                    if (error.networkResponse != null) {
                        message += " (Status: " + error.networkResponse.statusCode + ")";
                    } else if (error.getMessage() != null) {
                        message += " (" + error.getMessage() + ")";
                    } else {
                        message += " (Cek IP/Firewall/WiFi)";
                    }
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                });

        VolleySingleton.getInstance(this).addToRequestQueue(request);
    }
}
