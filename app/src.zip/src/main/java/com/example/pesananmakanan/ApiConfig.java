package com.example.pesananmakanan;

public class ApiConfig {
    // Pakai 10.0.2.2 jika pakai Emulator
    public static final String BASE_URL = "http://10.0.2.2/backend_api/";

    public static final String REGISTER_URL = BASE_URL + "register.php";

    public static final String OTP_REQUEST_URL = BASE_URL + "otp_request.php";
    public static final String OTP_VERIFY_URL = BASE_URL + "otp_verify.php";
    public static final String LOGIN_URL = BASE_URL + "login.php";
    public static final String PRODUK_URL = BASE_URL + "produk.php";
    public static final String PRODUK_SIMPAN_URL = BASE_URL + "produk_simpan.php";
    public static final String PRODUK_UPDATE_URL = BASE_URL + "produk_update.php";
    public static final String PRODUK_DELETE_URL = BASE_URL + "produk_delete.php";
    public static final String TRANSAKSI_URL = BASE_URL + "transaksi.php";
    public static final String DASHBOARD_URL = BASE_URL + "dashboard.php";
}