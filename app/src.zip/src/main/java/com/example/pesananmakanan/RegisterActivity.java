package com.example.pesananmakanan;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private EditText etEmail, etPass, etOtp;
    private LinearLayout layoutInputData, layoutInputOtp;
    private Button btnDoRegister, btnVerifyReg;
    private ProgressBar progressReg;
    private String emailTerdaftar = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etEmail = findViewById(R.id.etRegEmail);
        etPass = findViewById(R.id.etRegPass);
        etOtp = findViewById(R.id.etRegOtp);
        layoutInputData = findViewById(R.id.layoutInputData);
        layoutInputOtp = findViewById(R.id.layoutInputOtp);
        btnDoRegister = findViewById(R.id.btnDoRegister);
        btnVerifyReg = findViewById(R.id.btnVerifyReg);
        progressReg = findViewById(R.id.progressReg);

        btnDoRegister.setOnClickListener(v -> prosesDaftar());
        btnVerifyReg.setOnClickListener(v -> verifikasiOtp());
        findViewById(R.id.btnBackLogin).setOnClickListener(v -> finish());
    }

    private void prosesDaftar() {
        String email = etEmail.getText().toString().trim();
        String pass = etPass.getText().toString().trim();

        if (TextUtils.isEmpty(email)) { etEmail.setError("Isi email"); return; }
        if (TextUtils.isEmpty(pass)) { etPass.setError("Isi password"); return; }

        progressReg.setVisibility(View.VISIBLE);
        btnDoRegister.setEnabled(false);

        JSONObject body = new JSONObject();
        try {
            body.put("email", email);
            body.put("password", pass);
        } catch (Exception e) {}

        JsonObjectRequest req = new JsonObjectRequest(Request.Method.POST, ApiConfig.REGISTER_URL, body,
                res -> {
                    progressReg.setVisibility(View.GONE);
                    btnDoRegister.setEnabled(true);
                    try {
                        if (res.getString("status").equals("success")) {
                            emailTerdaftar = email;
                            Toast.makeText(this, "Berhasil! Cek email untuk kode OTP", Toast.LENGTH_LONG).show();
                            
                            // TAMPILKAN FIELD OTP
                            layoutInputData.setVisibility(View.GONE);
                            layoutInputOtp.setVisibility(View.VISIBLE);
                        } else {
                            Toast.makeText(this, res.optString("message", "Gagal daftar"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {}
                },
                err -> {
                    progressReg.setVisibility(View.GONE);
                    btnDoRegister.setEnabled(true);
                    Toast.makeText(this, "Jaringan Bermasalah", Toast.LENGTH_SHORT).show();
                });

        VolleySingleton.getInstance(this).addToRequestQueue(req);
    }

    private void verifikasiOtp() {
        String otp = etOtp.getText().toString().trim();
        if (otp.length() < 6) { etOtp.setError("Masukkan 6 digit OTP"); return; }

        progressReg.setVisibility(View.VISIBLE);
        btnVerifyReg.setEnabled(false);

        JSONObject body = new JSONObject();
        try {
            body.put("email", emailTerdaftar);
            body.put("kode_otp", otp);
        } catch (Exception e) {}

        // Menggunakan endpoint verifikasi yang sama
        JsonObjectRequest req = new JsonObjectRequest(Request.Method.POST, ApiConfig.OTP_VERIFY_URL, body,
                res -> {
                    progressReg.setVisibility(View.GONE);
                    btnVerifyReg.setEnabled(true);
                    try {
                        if (res.getString("status").equals("success")) {
                            Toast.makeText(this, "Akun Berhasil Diverifikasi!", Toast.LENGTH_LONG).show();
                            finish(); // Balik ke Login
                        } else {
                            Toast.makeText(this, res.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {}
                },
                err -> {
                    progressReg.setVisibility(View.GONE);
                    btnVerifyReg.setEnabled(true);
                    Toast.makeText(this, "Verifikasi Gagal (Jaringan)", Toast.LENGTH_SHORT).show();
                });

        VolleySingleton.getInstance(this).addToRequestQueue(req);
    }
}