package com.example.pesananmakanan;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class OTPActivity extends AppCompatActivity {

    private EditText etOtp;
    private Button btnVerifikasi;
    private ProgressBar progressOtp;
    private String emailUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        etOtp = findViewById(R.id.etOtp);
        btnVerifikasi = findViewById(R.id.btnVerifikasi);
        progressOtp = findViewById(R.id.progressOtp);

        // Ambil email dari activity sebelumnya (misal dari Login atau Lupa Password)
        emailUser = getIntent().getStringExtra("email");

        btnVerifikasi.setOnClickListener(v -> verifikasiOtp());
    }

    private void verifikasiOtp() {
        String otp = etOtp.getText().toString().trim();

        if (TextUtils.isEmpty(otp) || otp.length() < 6) {
            etOtp.setError("Masukkan 6 digit kode OTP");
            return;
        }

        progressOtp.setVisibility(View.VISIBLE);
        btnVerifikasi.setEnabled(false);

        StringRequest request = new StringRequest(Request.Method.POST, ApiConfig.OTP_VERIFY_URL,
                response -> {
                    progressOtp.setVisibility(View.GONE);
                    btnVerifikasi.setEnabled(true);
                    // Karena backend return JSON string, kita handle simpel saja dulu
                    if (response.contains("success")) {
                        Toast.makeText(this, "Verifikasi Berhasil!", Toast.LENGTH_SHORT).show();
                        // Lanjut ke Reset Password atau Login
                        finish();
                    } else {
                        Toast.makeText(this, "OTP Salah atau Expired", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressOtp.setVisibility(View.GONE);
                    btnVerifikasi.setEnabled(true);
                    Toast.makeText(this, "Gagal terhubung ke server", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("email", emailUser);
                params.put("kode_otp", otp);
                return params;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(request);
    }
}